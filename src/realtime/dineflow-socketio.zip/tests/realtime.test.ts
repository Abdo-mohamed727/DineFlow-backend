import http from 'http';
import mongoose from 'mongoose';
import { io as connectSocketClient, type Socket as ClientSocket } from 'socket.io-client';
import { createApp } from '../src/app';
import { startMemoryDB, stopMemoryDB, clearCollections } from './setup/memoryDb';
import { seedFixtures } from './helpers/fixtures';
import { authHeader } from './helpers/auth';
import { initSocketIO } from '../src/realtime/socket';
import request from 'supertest';
import { signToken } from '../src/utils/jwt';

/**
 * Socket.IO real-time tests.
 *
 * Strategy:
 *   - We start a REAL HTTP server (not just supertest) so Socket.IO can
 *     attach to it. The server listens on an ephemeral port (port 0).
 *   - We connect real Socket.IO clients (`socket.io-client`) with the
 *     `auth: { token }` handshake, just like the Flutter app will.
 *   - We then drive REST endpoints via supertest and assert that the
 *     connected socket clients received the expected events.
 */
describe('Socket.IO Realtime', () => {
  let httpServer: http.Server;
  let serverUrl: string;
  let app: ReturnType<typeof createApp>;
  let fixtures: Awaited<ReturnType<typeof seedFixtures>>;
  const openSockets: ClientSocket[] = [];

  beforeAll(async () => {
    const uri = await startMemoryDB();
    await mongoose.connect(uri);

    app = createApp();
    httpServer = http.createServer(app);
    initSocketIO(httpServer);

    await new Promise<void>((resolve) => {
      httpServer.listen(0, '127.0.0.1', () => resolve());
    });
    const addr = httpServer.address();
    const port = typeof addr === 'object' && addr ? addr.port : 0;
    serverUrl = `http://127.0.0.1:${port}`;
  }, 15000);

  afterAll(async () => {
    // Close all open client sockets first.
    for (const s of openSockets) {
      try { s.close(); } catch { /* ignore */ }
    }
    openSockets.length = 0;

    // Close the IO server.
    const { getIO } = await import('../src/realtime/socket');
    const io = getIO();
    if (io) {
      await new Promise<void>((resolve) => io.close(() => resolve()));
    }

    // Close the HTTP server.
    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
    await stopMemoryDB();
  }, 15000);

  beforeEach(async () => {
    await clearCollections();
    fixtures = await seedFixtures();
  });

  afterEach(() => {
    // Clean up any sockets that weren't explicitly closed in the test.
    for (const s of openSockets) {
      try { s.close(); } catch { /* ignore */ }
    }
    openSockets.length = 0;
  });

  /**
   * Connect a Socket.IO client with the given JWT role. Returns a promise
   * that resolves once the client is connected.
   */
  function connectClient(role: 'customer' | 'waiter' | 'kitchen', userId: string): Promise<ClientSocket> {
    const token = signToken(userId, role);
    return new Promise((resolve, reject) => {
      const client = connectSocketClient(serverUrl, {
        auth: { token },
        reconnection: false,
        timeout: 3000,
      });
      const timer = setTimeout(() => {
        client.close();
        reject(new Error('connect timeout'));
      }, 4000);
      // Wait for the server's `ready` event, which fires AFTER the server
      // has verified the JWT and joined the socket to its rooms. This avoids
      // the race where `connect` fires before the server has finished setup.
      client.on('ready', () => {
        clearTimeout(timer);
        openSockets.push(client);
        resolve(client);
      });
      client.on('connect_error', (err: Error) => {
        clearTimeout(timer);
        client.close();
        reject(err);
      });
    });
  }

  /**
   * Helper: add to cart + place order via REST. Returns the orderId.
   */
  async function placeOrder(): Promise<string> {
    await request(app)
      .post('/api/cart/items')
      .set(authHeader(fixtures.customer._id.toString(), 'customer'))
      .send({ productId: fixtures.burger._id.toString(), quantity: 1 });
    const res = await request(app)
      .post('/api/orders')
      .set(authHeader(fixtures.customer._id.toString(), 'customer'))
      .send({ orderType: 'TAKEAWAY' });
    return res.body.data.orderId;
  }

  /* ====================================================================== */
  /* Test 1: order_created reaches the kitchen room                         */
  /* ====================================================================== */
  it('1. customer creates order → kitchen socket receives "order_created"', async () => {
    const kitchenSocket = await connectClient('kitchen', fixtures.kitchen._id.toString());

    let received: { order?: { id?: string; orderNumber?: string; status?: string } } | null = null;
    kitchenSocket.on('order_created', (payload: { order?: { id?: string; orderNumber?: string; status?: string } }) => {
      received = payload;
    });

    const orderId = await placeOrder();
    await new Promise((r) => setTimeout(r, 200));

    expect(received).toBeTruthy();
    expect(received!.order).toBeTruthy();
    expect(received!.order!.id).toBe(orderId);
    expect(received!.order!.orderNumber).toBeTruthy();
    expect(received!.order!.status).toBe('pending');

    kitchenSocket.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 2: order_status_changed reaches the kitchen room                  */
  /* ====================================================================== */
  it('2. kitchen changes status → kitchen socket receives "order_status_changed"', async () => {
    const orderId = await placeOrder();

    const kitchenSocket = await connectClient('kitchen', fixtures.kitchen._id.toString());

    let received: { orderId?: string; newStatus?: string; oldStatus?: string } | null = null;
    kitchenSocket.on('order_status_changed', (payload: { orderId?: string; newStatus?: string; oldStatus?: string }) => {
      received = payload;
    });

    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set(authHeader(fixtures.kitchen._id.toString(), 'kitchen'))
      .send({ status: 'confirmed' });
    expect(res.status).toBe(200);

    await new Promise((r) => setTimeout(r, 200));

    expect(received).toBeTruthy();
    expect(received!.orderId).toBe(orderId);
    expect(received!.newStatus).toBe('confirmed');
    expect(received!.oldStatus).toBe('pending');

    kitchenSocket.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 3: non-kitchen user cannot join the kitchen room                  */
  /* ====================================================================== */
  it('3. customer attempting to join the kitchen room is denied', async () => {
    const customerSocket = await connectClient('customer', fixtures.customer._id.toString());

    const ack = await new Promise<{ ok: boolean; error?: string }>((resolve) => {
      customerSocket.emit('join_room', 'kitchen', (response: { ok: boolean; error?: string }) => {
        resolve(response);
      });
      setTimeout(() => resolve({ ok: true, error: 'timeout' }), 2000);
    });

    expect(ack.ok).toBe(false);
    expect(ack.error).toContain('Forbidden');

    customerSocket.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 4: client disconnect doesn't crash the backend                   */
  /* ====================================================================== */
  it('4. client disconnect → backend remains stable', async () => {
    const kitchenSocket = await connectClient('kitchen', fixtures.kitchen._id.toString());
    kitchenSocket.close();

    await new Promise((r) => setTimeout(r, 300));

    // Backend should still respond to REST requests.
    const res = await request(app)
      .get('/api/products')
      .set(authHeader(fixtures.customer._id.toString(), 'customer'));
    expect(res.status).toBe(200);

    // Socket.IO should still accept new connections.
    const newSocket = await connectClient('kitchen', fixtures.kitchen._id.toString());
    expect(newSocket.connected).toBe(true);
    newSocket.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 5: existing REST APIs still work                                 */
  /* ====================================================================== */
  it('5. existing REST APIs still work (POST /api/orders + PATCH status)', async () => {
    const addRes = await request(app)
      .post('/api/cart/items')
      .set(authHeader(fixtures.customer._id.toString(), 'customer'))
      .send({ productId: fixtures.burger._id.toString(), quantity: 2 });
    expect(addRes.status).toBe(201);

    const orderRes = await request(app)
      .post('/api/orders')
      .set(authHeader(fixtures.customer._id.toString(), 'customer'))
      .send({ orderType: 'TAKEAWAY' });
    expect(orderRes.status).toBe(201);
    const orderId = orderRes.body.data.orderId;

    const statusRes = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set(authHeader(fixtures.kitchen._id.toString(), 'kitchen'))
      .send({ status: 'confirmed' });
    expect(statusRes.status).toBe(200);
    expect(statusRes.body.data.order.status).toBe('confirmed');
  }, 10000);

  /* ====================================================================== */
  /* Test 6: customer receives order_status_changed in their user room      */
  /* ====================================================================== */
  it('6. customer receives "order_status_changed" on their user room', async () => {
    const orderId = await placeOrder();

    const customerSocket = await connectClient('customer', fixtures.customer._id.toString());

    let received: { orderId?: string; newStatus?: string } | null = null;
    customerSocket.on('order_status_changed', (payload: { orderId?: string; newStatus?: string }) => {
      received = payload;
    });

    await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set(authHeader(fixtures.kitchen._id.toString(), 'kitchen'))
      .send({ status: 'confirmed' });

    await new Promise((r) => setTimeout(r, 300));

    expect(received).toBeTruthy();
    expect(received!.orderId).toBe(orderId);
    expect(received!.newStatus).toBe('confirmed');

    customerSocket.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 7: no-token client is rejected                                    */
  /* ====================================================================== */
  it('7. client without a token is rejected', async () => {
    const client = connectSocketClient(serverUrl, { reconnection: false, timeout: 2000 });
    openSockets.push(client);

    // The server should reject the connection by emitting `auth_error` and
    // then disconnecting. We do NOT listen for `connect` — that event fires
    // briefly before the server's connection handler runs the rejection.
    const result = await new Promise<{ rejected: boolean }>((resolve) => {
      client.on('auth_error', () => resolve({ rejected: true }));
      client.on('disconnect', () => resolve({ rejected: true }));
      // Fallback: if neither fires, the client wasn't rejected.
      setTimeout(() => resolve({ rejected: false }), 3000);
    });

    expect(result.rejected).toBe(true);
    client.close();
  }, 10000);

  /* ====================================================================== */
  /* Test 8: invalid token client is rejected                               */
  /* ====================================================================== */
  it('8. client with an invalid token is rejected', async () => {
    const client = connectSocketClient(serverUrl, {
      auth: { token: 'this-is-not-a-valid-jwt' },
      reconnection: false,
      timeout: 2000,
    });
    openSockets.push(client);

    const result = await new Promise<{ rejected: boolean }>((resolve) => {
      client.on('auth_error', () => resolve({ rejected: true }));
      client.on('disconnect', () => resolve({ rejected: true }));
      setTimeout(() => resolve({ rejected: false }), 3000);
    });

    expect(result.rejected).toBe(true);
    client.close();
  }, 10000);
});
