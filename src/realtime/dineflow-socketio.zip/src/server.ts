import http from 'http';
import { createApp } from './app';
import { connectDB } from './config/database';
import { env } from './config/env';
import { initSocketIO } from './realtime/socket';

async function bootstrap() {
  await connectDB();
  const app = createApp();

  // Create a single HTTP server that serves BOTH:
  //   - Express REST API (app is the request listener)
  //   - Socket.IO websocket (attached to the same server)
  // This matches the architecture requirement: one server, one port.
  const server = http.createServer(app);

  // Attach Socket.IO to the existing HTTP server.
  // Safe to call in tests too — they don't call bootstrap(), so Socket.IO
  // is only initialized when the real server boots.
  initSocketIO(server);

  server.listen(env.PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`🚀 DineFlow API + Socket.IO running on http://localhost:${env.PORT} [${env.NODE_ENV}]`);
  });

  // Graceful shutdown
  const shutdown = async (signal: string) => {
    // eslint-disable-next-line no-console
    console.log(`\n${signal} received - shutting down...`);
    server.close(async () => {
      const { disconnectDB } = await import('./config/database');
      await disconnectDB();
      // eslint-disable-next-line no-console
      console.log('✅ Closed out remaining connections.');
      process.exit(0);
    });
    // Force-close after 10s
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('❌ Failed to start server:', err);
  process.exit(1);
});
